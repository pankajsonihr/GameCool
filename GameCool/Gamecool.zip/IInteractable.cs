﻿namespace GameCool
{
	 
	interface IInteractable
	{
		void Interact(Player player);

	}
}
